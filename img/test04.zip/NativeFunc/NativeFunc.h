#ifdef NATIVEFUNC_EXPORTS
#define NATIVEFUNC_API __declspec(dllexport)
#else
#define NATIVEFUNC_API __declspec(dllimport)
#endif

namespace Native
{
	// �z��𔽓]������֐��ł�
	NATIVEFUNC_API void Reverse(unsigned char* src, unsigned char* dst, int num);
}
