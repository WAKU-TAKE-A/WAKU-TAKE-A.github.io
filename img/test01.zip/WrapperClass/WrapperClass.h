#pragma once
using namespace System;

namespace Wrapper
{
	public ref class WrapperClass
	{
	public:
		int MemCopy(array<int>^ src, array<int>^ dst, int size);
	};
}