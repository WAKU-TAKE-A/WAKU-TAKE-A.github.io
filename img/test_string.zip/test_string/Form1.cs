﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// user add
using Wrapper;

namespace test_string
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();



            WrapperClass wr = new WrapperClass();

            // 元の文字列
            string str_src = "abcあいう漢字";
            char[] chrs = str_src.ToCharArray();

            // chrsの2番目の文字をXに変更します
            wr.WrChangeString(chrs, 2);
            string str_dst = new string(chrs);

            // 結果表示
            MessageBox.Show(string.Format("元の文字は、\r\n{0}\r\n変更後は、\r\n{1}", str_src, str_dst));
            Environment.Exit(0);
        }
    }
}
