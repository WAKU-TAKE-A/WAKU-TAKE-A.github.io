#include "stdafx.h"
#include "NativeFunc.h"

void Native::FuncClass::Max(int* src, int num, int* mx, int* mxIndex)
{
	*mx = src[0];
	*mxIndex = 0;

	for (int i = 0; i < num; i++) {
		if (src[i] > *mx) {
			*mxIndex = i;
			*mx = src[i];
		}
	}
}