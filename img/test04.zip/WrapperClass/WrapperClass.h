// WrapperClass.h

#pragma once

using namespace System;

namespace Wrapper {

	public ref class WrapperClass
	{
	public:
		void Reverse(System::Drawing::Bitmap^ src, System::Drawing::Bitmap^ dst, int num);
	};
}
