﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Wrapper;

namespace test01
{
    public partial class Form1 : Form
    {
        WrapperClass _wr = new WrapperClass(); //WrapperClassのインスタンスを作成

        public Form1()
        {
            InitializeComponent();

            int[] a = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int[] b = new int[10];

            MessageBox.Show("処理前：b[0]=" + b[0].ToString() +
                ", b[5]=" + b[5].ToString() +
                ", b[10]=" + b[9].ToString());

            _wr.MemCopy(a, b, 10); //処理実行（C#のインテリセンスも働きます）

            MessageBox.Show("処理後：b[0]=" + b[0].ToString() +
                ", b[5]=" + b[5].ToString() +
                ", b[10]=" + b[9].ToString());

            Environment.Exit(0);
        }
    }
}
