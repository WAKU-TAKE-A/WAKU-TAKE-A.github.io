﻿#include "stdafx.h"
#include<vcclr.h>
#include "..\WrapperClass\WrapperClass.h"

// ----------------------------------------------
// Constructor, Destructor, Finalizer
// ----------------------------------------------
Wrapper::WrapperClass::WrapperClass()
{
    // do nothing
}

Wrapper::WrapperClass::!WrapperClass()
{
    // do nothing
}

Wrapper::WrapperClass::~WrapperClass()
{
    // do nothing
}

// ----------------------------------------------
// The definition of public member functions
// ----------------------------------------------
void Wrapper::WrapperClass::WrChangeString(array<System::Char>^ srcdst, int n)
{
	if (srcdst == nullptr) { return; }
	pin_ptr<System::Char> p_srcdst = &srcdst[0];

	ChangeString(p_srcdst, n);

	p_srcdst = nullptr;
}