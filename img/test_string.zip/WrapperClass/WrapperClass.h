﻿#pragma once

#include <string>
#include "..\NativeFunc\NativeFunc.h"

using namespace System;
using namespace System::Runtime::InteropServices;
using namespace System::Collections::Generic;

namespace Wrapper
{
    public ref class WrapperClass
    {
    public:
        // Constructor, Destructor, Finalizer
        WrapperClass();
        ~WrapperClass();
        !WrapperClass();

		// Public member functions
        void WrChangeString(array<System::Char>^ srcdst, int n);
    };
}
